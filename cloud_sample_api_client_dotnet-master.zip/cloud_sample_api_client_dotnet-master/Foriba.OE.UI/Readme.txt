﻿

Web servis erişimi için  Web Servis Bağlantı klavuzunu okumanız gerekmektedir.

e-Fatura web servis metodlarının kullanımı için  https://api.fitbulut.com/docs/  adresinde bulunan e-Fatura WS API 2.1 veya e-Fatura WS API 2.2 Dokümantasyonunu okumanız gerekmektedir.
e-Arşiv web servis  metodlarının kullanımı için  https://api.fitbulut.com/docs/  adresinde bulunan e-Arşiv WS API 2.0 Dokümantasyonunu okumanız gerekmektedir.
e-İrsaliye web servis  metodlarının kullanımı için  https://api.fitbulut.com/docs/  adresinde bulunan e-İrsaliye WS API 1.2 Dokümantasyonunu okumanız gerekmektedir.
e-Smm web servis  metodlarının kullanımı için  https://api.fitbulut.com/docs/  adresinde bulunan e-Smm WS API 1.0 Dokümantasyonunu okumanız gerekmektedir.
e-Mm web servis  metodlarının kullanımı için  https://api.fitbulut.com/docs/  adresinde bulunan e-Mm WS API 1.0 Dokümantasyonunu okumanız gerekmektedir.