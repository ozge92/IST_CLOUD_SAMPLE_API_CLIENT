﻿using System;


namespace Foriba.OE.UI.Exceptions
{
    public class NumericVknTcknException : Exception
    {
        public NumericVknTcknException(string message) : base(message)
        {

        }
    }
}
