﻿using System;


namespace Foriba.OE.UI.Exceptions
{
    public class UUIDNullException : Exception
    {
    
        public UUIDNullException(string message) : base(message)
        {

        }
    }
}
