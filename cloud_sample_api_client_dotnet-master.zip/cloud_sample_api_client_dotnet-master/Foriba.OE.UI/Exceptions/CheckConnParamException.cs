﻿using System;


namespace Foriba.OE.UI.Exceptions
{
    public class CheckConnParamException : Exception
    {

        public CheckConnParamException(string message) : base(message)
        {

        }
    }
}
