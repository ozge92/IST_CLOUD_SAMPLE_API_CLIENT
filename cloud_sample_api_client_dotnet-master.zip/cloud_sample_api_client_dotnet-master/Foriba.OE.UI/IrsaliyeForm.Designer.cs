﻿namespace FITBulutFaturaTestProject
{
    partial class frmIrsaliye
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIrsaliye));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelControls = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.dtpIrsaliyeTarih2 = new System.Windows.Forms.DateTimePicker();
            this.label33 = new System.Windows.Forms.Label();
            this.dtpIrsaliyeTarih1 = new System.Windows.Forms.DateTimePicker();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtKullanici = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtPostaKutusu = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtGonBirim = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtTcVkn = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnGonZarf = new System.Windows.Forms.Button();
            this.btnGelZarf = new System.Windows.Forms.Button();
            this.btnIrsaliyeHtmlIndir = new System.Windows.Forms.Button();
            this.btnGonIrsYanit = new System.Windows.Forms.Button();
            this.btnIrsaliyeGon = new System.Windows.Forms.Button();
            this.btnIrsaliyePdfIndir = new System.Windows.Forms.Button();
            this.btnIrsaliyeUblIndir = new System.Windows.Forms.Button();
            this.btnZarfDurumSorgula = new System.Windows.Forms.Button();
            this.btnIrsYanitGon = new System.Windows.Forms.Button();
            this.btnGonIrsaliye = new System.Windows.Forms.Button();
            this.btnGelIrsYanit = new System.Windows.Forms.Button();
            this.btnMukSorgu = new System.Windows.Forms.Button();
            this.btnGelIrsaliye = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.grdListIrsaliye = new System.Windows.Forms.DataGridView();
            this.lblBaslik = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelControls.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdListIrsaliye)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panelControls);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1263, 132);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(990, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(273, 132);
            this.panel3.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(271, 130);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 53;
            this.pictureBox3.TabStop = false;
            // 
            // panelControls
            // 
            this.panelControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelControls.Controls.Add(this.label32);
            this.panelControls.Controls.Add(this.dtpIrsaliyeTarih2);
            this.panelControls.Controls.Add(this.label33);
            this.panelControls.Controls.Add(this.dtpIrsaliyeTarih1);
            this.panelControls.Controls.Add(this.txtSifre);
            this.panelControls.Controls.Add(this.label35);
            this.panelControls.Controls.Add(this.txtKullanici);
            this.panelControls.Controls.Add(this.label34);
            this.panelControls.Controls.Add(this.txtPostaKutusu);
            this.panelControls.Controls.Add(this.label36);
            this.panelControls.Controls.Add(this.txtGonBirim);
            this.panelControls.Controls.Add(this.label37);
            this.panelControls.Controls.Add(this.txtTcVkn);
            this.panelControls.Controls.Add(this.label38);
            this.panelControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControls.Location = new System.Drawing.Point(0, 0);
            this.panelControls.Name = "panelControls";
            this.panelControls.Size = new System.Drawing.Size(1263, 132);
            this.panelControls.TabIndex = 0;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.Location = new System.Drawing.Point(774, 69);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(90, 20);
            this.label32.TabIndex = 50;
            this.label32.Text = "Bitiş Tarihi";
            // 
            // dtpIrsaliyeTarih2
            // 
            this.dtpIrsaliyeTarih2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtpIrsaliyeTarih2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIrsaliyeTarih2.Location = new System.Drawing.Point(773, 89);
            this.dtpIrsaliyeTarih2.Margin = new System.Windows.Forms.Padding(4);
            this.dtpIrsaliyeTarih2.Name = "dtpIrsaliyeTarih2";
            this.dtpIrsaliyeTarih2.Size = new System.Drawing.Size(168, 26);
            this.dtpIrsaliyeTarih2.TabIndex = 43;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.Location = new System.Drawing.Point(774, 13);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(130, 20);
            this.label33.TabIndex = 49;
            this.label33.Text = "Başlangıç Tarihi";
            // 
            // dtpIrsaliyeTarih1
            // 
            this.dtpIrsaliyeTarih1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtpIrsaliyeTarih1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIrsaliyeTarih1.Location = new System.Drawing.Point(773, 32);
            this.dtpIrsaliyeTarih1.Margin = new System.Windows.Forms.Padding(4);
            this.dtpIrsaliyeTarih1.Name = "dtpIrsaliyeTarih1";
            this.dtpIrsaliyeTarih1.Size = new System.Drawing.Size(168, 26);
            this.dtpIrsaliyeTarih1.TabIndex = 42;
            // 
            // txtSifre
            // 
            this.txtSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSifre.Location = new System.Drawing.Point(563, 89);
            this.txtSifre.Margin = new System.Windows.Forms.Padding(4);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(189, 26);
            this.txtSifre.TabIndex = 41;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(561, 69);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(76, 20);
            this.label35.TabIndex = 48;
            this.label35.Text = "WS Şifre";
            // 
            // txtKullanici
            // 
            this.txtKullanici.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKullanici.Location = new System.Drawing.Point(563, 32);
            this.txtKullanici.Margin = new System.Windows.Forms.Padding(4);
            this.txtKullanici.Name = "txtKullanici";
            this.txtKullanici.Size = new System.Drawing.Size(189, 26);
            this.txtKullanici.TabIndex = 40;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.Location = new System.Drawing.Point(561, 13);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(133, 20);
            this.label34.TabIndex = 47;
            this.label34.Text = "WS Kullanıcı Adı";
            // 
            // txtPostaKutusu
            // 
            this.txtPostaKutusu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPostaKutusu.Location = new System.Drawing.Point(213, 89);
            this.txtPostaKutusu.Margin = new System.Windows.Forms.Padding(4);
            this.txtPostaKutusu.Name = "txtPostaKutusu";
            this.txtPostaKutusu.Size = new System.Drawing.Size(331, 26);
            this.txtPostaKutusu.TabIndex = 39;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(210, 69);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(160, 20);
            this.label36.TabIndex = 46;
            this.label36.Text = "Posta Kutusu Etiketi";
            // 
            // txtGonBirim
            // 
            this.txtGonBirim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtGonBirim.Location = new System.Drawing.Point(213, 32);
            this.txtGonBirim.Margin = new System.Windows.Forms.Padding(4);
            this.txtGonBirim.Name = "txtGonBirim";
            this.txtGonBirim.Size = new System.Drawing.Size(331, 26);
            this.txtGonBirim.TabIndex = 38;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(210, 13);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(177, 20);
            this.label37.TabIndex = 45;
            this.label37.Text = "Gönderici Birim Etiketi";
            // 
            // txtTcVkn
            // 
            this.txtTcVkn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtTcVkn.Location = new System.Drawing.Point(21, 32);
            this.txtTcVkn.Margin = new System.Windows.Forms.Padding(4);
            this.txtTcVkn.Name = "txtTcVkn";
            this.txtTcVkn.Size = new System.Drawing.Size(172, 26);
            this.txtTcVkn.TabIndex = 37;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.Location = new System.Drawing.Point(21, 13);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(103, 20);
            this.label38.TabIndex = 44;
            this.label38.Text = "TCKN / VKN";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.btnGonZarf);
            this.panel4.Controls.Add(this.btnGelZarf);
            this.panel4.Controls.Add(this.btnIrsaliyeHtmlIndir);
            this.panel4.Controls.Add(this.btnGonIrsYanit);
            this.panel4.Controls.Add(this.btnIrsaliyeGon);
            this.panel4.Controls.Add(this.btnIrsaliyePdfIndir);
            this.panel4.Controls.Add(this.btnIrsaliyeUblIndir);
            this.panel4.Controls.Add(this.btnZarfDurumSorgula);
            this.panel4.Controls.Add(this.btnIrsYanitGon);
            this.panel4.Controls.Add(this.btnGonIrsaliye);
            this.panel4.Controls.Add(this.btnGelIrsYanit);
            this.panel4.Controls.Add(this.btnMukSorgu);
            this.panel4.Controls.Add(this.btnGelIrsaliye);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(990, 132);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(273, 721);
            this.panel4.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(3, 550);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(263, 1);
            this.label11.TabIndex = 122;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(3, 391);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(263, 1);
            this.label10.TabIndex = 121;
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(3, 232);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(263, 1);
            this.label9.TabIndex = 120;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(3, 74);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(265, 1);
            this.label12.TabIndex = 119;
            // 
            // btnGonZarf
            // 
            this.btnGonZarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGonZarf.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGonZarf.Location = new System.Drawing.Point(33, 240);
            this.btnGonZarf.Margin = new System.Windows.Forms.Padding(4);
            this.btnGonZarf.Name = "btnGonZarf";
            this.btnGonZarf.Size = new System.Drawing.Size(209, 40);
            this.btnGonZarf.TabIndex = 110;
            this.btnGonZarf.Text = "Gönderilen Zarflar";
            this.btnGonZarf.UseVisualStyleBackColor = true;
            this.btnGonZarf.Click += new System.EventHandler(this.btnGonZarf_Click);
            // 
            // btnGelZarf
            // 
            this.btnGelZarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGelZarf.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGelZarf.Location = new System.Drawing.Point(33, 81);
            this.btnGelZarf.Margin = new System.Windows.Forms.Padding(4);
            this.btnGelZarf.Name = "btnGelZarf";
            this.btnGelZarf.Size = new System.Drawing.Size(209, 40);
            this.btnGelZarf.TabIndex = 107;
            this.btnGelZarf.Text = "Gelen Zarflar";
            this.btnGelZarf.UseVisualStyleBackColor = true;
            this.btnGelZarf.Click += new System.EventHandler(this.btnGelZarf_Click);
            // 
            // btnIrsaliyeHtmlIndir
            // 
            this.btnIrsaliyeHtmlIndir.Enabled = false;
            this.btnIrsaliyeHtmlIndir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrsaliyeHtmlIndir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIrsaliyeHtmlIndir.Location = new System.Drawing.Point(33, 557);
            this.btnIrsaliyeHtmlIndir.Margin = new System.Windows.Forms.Padding(4);
            this.btnIrsaliyeHtmlIndir.Name = "btnIrsaliyeHtmlIndir";
            this.btnIrsaliyeHtmlIndir.Size = new System.Drawing.Size(209, 40);
            this.btnIrsaliyeHtmlIndir.TabIndex = 116;
            this.btnIrsaliyeHtmlIndir.Text = "İrsaliye HTML İndir";
            this.btnIrsaliyeHtmlIndir.UseVisualStyleBackColor = true;
            this.btnIrsaliyeHtmlIndir.Click += new System.EventHandler(this.btnIrsaliyeHtmlIndir_Click);
            // 
            // btnGonIrsYanit
            // 
            this.btnGonIrsYanit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGonIrsYanit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGonIrsYanit.Location = new System.Drawing.Point(33, 341);
            this.btnGonIrsYanit.Margin = new System.Windows.Forms.Padding(4);
            this.btnGonIrsYanit.Name = "btnGonIrsYanit";
            this.btnGonIrsYanit.Size = new System.Drawing.Size(211, 40);
            this.btnGonIrsYanit.TabIndex = 112;
            this.btnGonIrsYanit.Text = "Gönderilen İrsaliye Yanıtları";
            this.btnGonIrsYanit.UseVisualStyleBackColor = true;
            this.btnGonIrsYanit.Click += new System.EventHandler(this.btnGonIrsYanit_Click);
            // 
            // btnIrsaliyeGon
            // 
            this.btnIrsaliyeGon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrsaliyeGon.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIrsaliyeGon.Location = new System.Drawing.Point(33, 398);
            this.btnIrsaliyeGon.Margin = new System.Windows.Forms.Padding(4);
            this.btnIrsaliyeGon.Name = "btnIrsaliyeGon";
            this.btnIrsaliyeGon.Size = new System.Drawing.Size(209, 40);
            this.btnIrsaliyeGon.TabIndex = 113;
            this.btnIrsaliyeGon.Text = "İrsaliye Gönder";
            this.btnIrsaliyeGon.UseVisualStyleBackColor = true;
            this.btnIrsaliyeGon.Click += new System.EventHandler(this.btnIrsaliyeGon_Click);
            // 
            // btnIrsaliyePdfIndir
            // 
            this.btnIrsaliyePdfIndir.Enabled = false;
            this.btnIrsaliyePdfIndir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrsaliyePdfIndir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIrsaliyePdfIndir.Location = new System.Drawing.Point(33, 608);
            this.btnIrsaliyePdfIndir.Margin = new System.Windows.Forms.Padding(4);
            this.btnIrsaliyePdfIndir.Name = "btnIrsaliyePdfIndir";
            this.btnIrsaliyePdfIndir.Size = new System.Drawing.Size(209, 40);
            this.btnIrsaliyePdfIndir.TabIndex = 117;
            this.btnIrsaliyePdfIndir.Text = "İrsaliye PDF İndir";
            this.btnIrsaliyePdfIndir.UseVisualStyleBackColor = true;
            this.btnIrsaliyePdfIndir.Click += new System.EventHandler(this.btnIrsaliyePdfIndir_Click);
            // 
            // btnIrsaliyeUblIndir
            // 
            this.btnIrsaliyeUblIndir.Enabled = false;
            this.btnIrsaliyeUblIndir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrsaliyeUblIndir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIrsaliyeUblIndir.Location = new System.Drawing.Point(33, 656);
            this.btnIrsaliyeUblIndir.Margin = new System.Windows.Forms.Padding(4);
            this.btnIrsaliyeUblIndir.Name = "btnIrsaliyeUblIndir";
            this.btnIrsaliyeUblIndir.Size = new System.Drawing.Size(209, 40);
            this.btnIrsaliyeUblIndir.TabIndex = 118;
            this.btnIrsaliyeUblIndir.Text = "İrsaliye UBL İndir";
            this.btnIrsaliyeUblIndir.UseVisualStyleBackColor = true;
            this.btnIrsaliyeUblIndir.Click += new System.EventHandler(this.btnIrsaliyeUblIndir_Click);
            // 
            // btnZarfDurumSorgula
            // 
            this.btnZarfDurumSorgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnZarfDurumSorgula.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZarfDurumSorgula.Location = new System.Drawing.Point(33, 499);
            this.btnZarfDurumSorgula.Margin = new System.Windows.Forms.Padding(4);
            this.btnZarfDurumSorgula.Name = "btnZarfDurumSorgula";
            this.btnZarfDurumSorgula.Size = new System.Drawing.Size(209, 40);
            this.btnZarfDurumSorgula.TabIndex = 115;
            this.btnZarfDurumSorgula.Text = "Zarf Durumu Sorgula";
            this.btnZarfDurumSorgula.UseVisualStyleBackColor = true;
            this.btnZarfDurumSorgula.Click += new System.EventHandler(this.btnZarfDurumSorgula_Click);
            // 
            // btnIrsYanitGon
            // 
            this.btnIrsYanitGon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrsYanitGon.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIrsYanitGon.Location = new System.Drawing.Point(33, 449);
            this.btnIrsYanitGon.Margin = new System.Windows.Forms.Padding(4);
            this.btnIrsYanitGon.Name = "btnIrsYanitGon";
            this.btnIrsYanitGon.Size = new System.Drawing.Size(209, 40);
            this.btnIrsYanitGon.TabIndex = 114;
            this.btnIrsYanitGon.Text = "İrsaliye Yanıtı Gönder";
            this.btnIrsYanitGon.UseVisualStyleBackColor = true;
            this.btnIrsYanitGon.Click += new System.EventHandler(this.btnIrsYanitGon_Click);
            // 
            // btnGonIrsaliye
            // 
            this.btnGonIrsaliye.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGonIrsaliye.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGonIrsaliye.Location = new System.Drawing.Point(33, 290);
            this.btnGonIrsaliye.Margin = new System.Windows.Forms.Padding(4);
            this.btnGonIrsaliye.Name = "btnGonIrsaliye";
            this.btnGonIrsaliye.Size = new System.Drawing.Size(209, 40);
            this.btnGonIrsaliye.TabIndex = 111;
            this.btnGonIrsaliye.Text = "Gönderilen İrsaliyeler";
            this.btnGonIrsaliye.UseVisualStyleBackColor = true;
            this.btnGonIrsaliye.Click += new System.EventHandler(this.btnGonIrsaliye_Click);
            // 
            // btnGelIrsYanit
            // 
            this.btnGelIrsYanit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGelIrsYanit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGelIrsYanit.Location = new System.Drawing.Point(33, 182);
            this.btnGelIrsYanit.Margin = new System.Windows.Forms.Padding(4);
            this.btnGelIrsYanit.Name = "btnGelIrsYanit";
            this.btnGelIrsYanit.Size = new System.Drawing.Size(209, 40);
            this.btnGelIrsYanit.TabIndex = 109;
            this.btnGelIrsYanit.Text = "Gelen İrsaliye Yanıtları";
            this.btnGelIrsYanit.UseVisualStyleBackColor = true;
            this.btnGelIrsYanit.Click += new System.EventHandler(this.btnGelIrsYanit_Click);
            // 
            // btnMukSorgu
            // 
            this.btnMukSorgu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMukSorgu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnMukSorgu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMukSorgu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMukSorgu.Location = new System.Drawing.Point(33, 23);
            this.btnMukSorgu.Margin = new System.Windows.Forms.Padding(4);
            this.btnMukSorgu.Name = "btnMukSorgu";
            this.btnMukSorgu.Size = new System.Drawing.Size(209, 40);
            this.btnMukSorgu.TabIndex = 106;
            this.btnMukSorgu.Text = "Mükellef Sorgula";
            this.btnMukSorgu.UseVisualStyleBackColor = true;
            this.btnMukSorgu.Click += new System.EventHandler(this.btnMukSorgu_Click);
            // 
            // btnGelIrsaliye
            // 
            this.btnGelIrsaliye.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGelIrsaliye.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGelIrsaliye.Location = new System.Drawing.Point(33, 131);
            this.btnGelIrsaliye.Margin = new System.Windows.Forms.Padding(4);
            this.btnGelIrsaliye.Name = "btnGelIrsaliye";
            this.btnGelIrsaliye.Size = new System.Drawing.Size(209, 40);
            this.btnGelIrsaliye.TabIndex = 108;
            this.btnGelIrsaliye.Text = "Gelen İrsaliyeler\r\n";
            this.btnGelIrsaliye.UseVisualStyleBackColor = true;
            this.btnGelIrsaliye.Click += new System.EventHandler(this.btnGelIrsaliye_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.grdListIrsaliye);
            this.panel5.Controls.Add(this.lblBaslik);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 132);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(990, 721);
            this.panel5.TabIndex = 2;
            // 
            // grdListIrsaliye
            // 
            this.grdListIrsaliye.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdListIrsaliye.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdListIrsaliye.Location = new System.Drawing.Point(0, 46);
            this.grdListIrsaliye.Name = "grdListIrsaliye";
            this.grdListIrsaliye.RowTemplate.Height = 24;
            this.grdListIrsaliye.Size = new System.Drawing.Size(990, 675);
            this.grdListIrsaliye.TabIndex = 1;
            this.grdListIrsaliye.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdListIrsaliye_CellClick);
            // 
            // lblBaslik
            // 
            this.lblBaslik.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBaslik.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblBaslik.Location = new System.Drawing.Point(0, 0);
            this.lblBaslik.Name = "lblBaslik";
            this.lblBaslik.Size = new System.Drawing.Size(990, 46);
            this.lblBaslik.TabIndex = 0;
            this.lblBaslik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmIrsaliye
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1263, 853);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "frmIrsaliye";
            this.Text = "IrsaliyeForm";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelControls.ResumeLayout(false);
            this.panelControls.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdListIrsaliye)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panelControls;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblBaslik;
        private System.Windows.Forms.DataGridView grdListIrsaliye;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.DateTimePicker dtpIrsaliyeTarih2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dtpIrsaliyeTarih1;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtKullanici;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtPostaKutusu;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtGonBirim;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtTcVkn;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGonZarf;
        private System.Windows.Forms.Button btnGelZarf;
        private System.Windows.Forms.Button btnIrsaliyeHtmlIndir;
        private System.Windows.Forms.Button btnGonIrsYanit;
        private System.Windows.Forms.Button btnIrsaliyeGon;
        private System.Windows.Forms.Button btnIrsaliyePdfIndir;
        private System.Windows.Forms.Button btnIrsaliyeUblIndir;
        private System.Windows.Forms.Button btnZarfDurumSorgula;
        private System.Windows.Forms.Button btnIrsYanitGon;
        private System.Windows.Forms.Button btnGonIrsaliye;
        private System.Windows.Forms.Button btnGelIrsYanit;
        private System.Windows.Forms.Button btnMukSorgu;
        private System.Windows.Forms.Button btnGelIrsaliye;
    }
}